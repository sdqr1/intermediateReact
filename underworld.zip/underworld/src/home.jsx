
import "./Home.css";



const Home = () => {
    return (
        <div className="home-page">
            <h1>Underworld Store</h1>
            <h4>Killer products, always!</h4>

            <link to=".catalog" className="btn btn-info">
                Check our amazing catalog!
            </link>
        </div>
    )
};

export default Home;