import "./cart.css";

const Cart = () => {
    return (
        <div className="cart-page">
            <h3>Let's finish the order!!!</h3>
        </div>
    );
};

export default Cart;